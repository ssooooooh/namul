<?php
	$connect = mysql_connect("localhost", "root", "apmsetup");
	$db = mysql_select_db('namulDB', $connect);
	
	if($db)
		echo "DB접속 성공";
	else
		echo "DB접속 실패";	

	$filename = "harm.txt";  //단어 정보 line을 담고있는 파일

	$row = file($filename);

	echo count($row);	
	$sql = "drop table if exists harm";
	mysql_query($sql);
	$sql = "create table if not exists harm(_id integer auto_increment, primary key(_id), name char(30), effect text)";

	$re = mysql_query($sql);
	if($re)
		echo "테이블 생성 성공";
	else
		echo "테이블 생성 실패";
	
	for($i = 0; $i < count($row); $i++)
	{
		$tok = explode("\t", $row[$i]);
		$insert = "insert into ingredient values('";
		for($j = 0; $j < count($tok); $j++)
		{
			echo $tok[$j];
			if($j == count($tok)-1)
				$insert .= $tok[$j]."')";
			else
				$insert .= $tok[$j]."', '";
		}
		mysql_query($insert);
	}
?>